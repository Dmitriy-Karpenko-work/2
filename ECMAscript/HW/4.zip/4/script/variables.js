//создаем пустой массив для дальнейшей работы с ним
let tempArr = [];

let checkboxesApiArr = [];

const apiUrlUsers = "https://jsonplaceholder.typicode.com/users";

//контейнер каталога
const CatalogEl = document.querySelector("div.catalog");

//радио кнопки выбор задания
const radio1 = document.getElementById("radio1");
const radio2 = document.getElementById("radio2");
