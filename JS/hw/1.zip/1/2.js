"use strict";

/*
Необходимо создать переменную name, записать в эту переменную свое имя.
Необходимо также создать переменную admin и присвоить этой переменной значение
из переменной name.
Вывести значение переменной admin в консоль.
*/

const inputUserName = prompt("введите имя");
const adminName = inputUserName;
console.log(`имя 'admin:'${adminName}`);
